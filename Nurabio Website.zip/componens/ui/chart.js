// components/ui/chart.js
export const Chart = () => null
export const ChartContainer = () => null
export const ChartTooltip = () => null
export const ChartTooltipContent = () => null
export const ChartLegend = () => null
export const ChartLegendContent = () => null
export const ChartStyle = () => null
